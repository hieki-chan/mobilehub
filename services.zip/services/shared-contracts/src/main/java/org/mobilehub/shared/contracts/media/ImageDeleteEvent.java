package org.mobilehub.shared.contracts.media;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ImageDeleteEvent {
    private String publicId;
}
