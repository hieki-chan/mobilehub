package org.mobilehub.shared.contracts.media;

public class ImageTopics {
    public static final String IMAGE_UPLOAD = "image.upload";
    public static final String IMAGE_UPLOADED = "image.uploaded";
    public static final String IMAGE_DELETE = "image.delete";
}
