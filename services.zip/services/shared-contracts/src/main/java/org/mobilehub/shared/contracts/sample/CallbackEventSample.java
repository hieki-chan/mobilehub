package org.mobilehub.shared_contracts.sample;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CallbackEventSample {
    int processedValue;
}
