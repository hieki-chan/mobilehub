package org.mobilehub.order_service.entity;

public enum OrderStatus {
    PENDING,
    SHIPPED,
    DELIVERED,
    CANCELLED,
    FAILED
}