package org.mobilehub.order_service.entity;

public enum OrderStatus { PENDING, PAID, SHIPPED, DELIVERED, CANCELLED, FAILED }
