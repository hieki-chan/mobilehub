package org.mobilehub.order_service.entity;

public enum PaymentMethod {
    COD,
    BANK_TRANSFER,
    CREDIT_CARD,
    E_WALLET
}