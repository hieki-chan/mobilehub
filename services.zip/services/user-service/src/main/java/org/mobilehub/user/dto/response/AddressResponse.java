package org.mobilehub.user.dto.response;

public class AddressResponse {
}
