package org.mobilehub.product.entity;

public enum ImageStatus {
    PENDING, UPLOADED, FAILED
}
