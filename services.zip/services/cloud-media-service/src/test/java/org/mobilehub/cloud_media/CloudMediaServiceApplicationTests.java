package org.mobilehub.cloud_media;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudMediaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
