package org.mobilehub.cloud_media;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudMediaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudMediaServiceApplication.class, args);
	}

}
