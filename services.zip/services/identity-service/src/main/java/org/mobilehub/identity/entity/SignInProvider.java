package org.mobilehub.identity.entity;

public enum SignInProvider {
    PASSWORD,
    GOOGLE
}
