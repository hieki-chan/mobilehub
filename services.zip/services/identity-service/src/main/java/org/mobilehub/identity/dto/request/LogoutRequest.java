package org.mobilehub.identity.dto.request;

public class LogoutRequest {
}
